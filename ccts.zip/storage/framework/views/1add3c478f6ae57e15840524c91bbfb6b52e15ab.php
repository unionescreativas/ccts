<?php $__env->startSection('content'); ?>
<div class="page-content container-fluid">
    <?php echo $__env->make('voyager::alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-12">

            <div class="admin-section-title">
                <h3><i class="voyager-upload"></i> Cargar Documento Rut</h3>
            </div>
            <div class="clear"></div>

<div id="app">
    <example-component></example-component>
</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ccts\resources\views/vendor/voyager/rut/edit-add.blade.php ENDPATH**/ ?>