<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cuentascobro extends Model {
    protected $table = 'cuentascobros';

}
